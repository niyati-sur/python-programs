"""************Your First Python Program***************"""
# This is the Online Python Shell
# Remove the # symbol to run a line of code when you see “Uncomment the statement and click Run”
# REMEMBER: If you uncomment statements you are not supposed to then you will get errors when executing your program
"""----------------Task1: Greetings---------------"""
# Are you ready to write your first program? 
# Let's start with a greeting.
# Remove the # symbol from the statement given below and hit the run button 
print('Hey Python')
# You should see "Hey Python" on the output terminal window
""" Congratulations! You've just created your first Python program"""
# Print command sends messages to the output window
# The parentheses () after the print command is mandatory
# The quote marks ' ' acts as a container for the text. 
# Without quotes, Python will think it is a command and will throw an error
"""----------------Task2: Hello World---------------"""
# Now try to display "Hello World"
# Hint: Type the print statement, within bracket or parentheses 
# Type Hello World, within quotes and hit Run to test your code
print("Hello World!")
"""----------------Task3: Your Message --------------"""
# Try sending a message of your choice to the output terminal window.
print("what's up :/")
# Did you get your desired output?
# Now try removing the ' ' and the ( ) from the print command. 
# Did you get an error? 
# Go ahead and fix the errors.
"""--------------Task4: What is a program? --------------"""
# Using print display the below on separate lines:
print("A computer program is a set of commands that you tell the dumb hardware what to do")
print("Software is a collection of computer programs.")
""" Awesome! You have learnt to use the print command and converse with Python """