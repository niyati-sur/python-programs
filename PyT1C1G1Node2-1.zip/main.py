"""************Your First Text Art***************"""
# Are you ready to create your first text art using Python?
# REMEMBER: If you uncomment statements you are not supposed to, you will run into errors.
"""-----------Task 1:Create a Simple Smiley---------------"""
print(" ")
print("*** Task 1: ***")
# Have you created a picture on your computer? Which tools have you used? 
# Do you know some of the special characters on your keyboard? 
# Can you draw any picture using special characters? 
# Come let us explore! To create a simple smiley using special characters
# Uncomment the print statements 
print("^ ^")
print(" - ")
# Click Run and see what is displayed.

"""------------Task 2: Create Another Smiley-------------"""
print(" ")
print("*** Task 2: ***")
# Can you create another smiley
print("- -")
print(" _ ")

"""-------------Task 3: Make a Blank Face---------------"""
print(" ")
print("*** Task 3: ***")
# Put on our creative hat!!
# Create a blank face using just these three characters:  @   -   |
# Hint: Use multiple print statements
print("@ @")
print(" |")
print(" -")
"""-------------Task 4: Create a Goat Face---------------"""
print(" ")
print("*** Task 4: ***")
# Now can you make  an animal face using the special characters, say goat?
# First two lines are done for you, uncomment them

print ("(\___/)" )
print (" \* */ ")

# Add more print statements to complete this picture.
# Click on Run and enjoy your masterpiece on the terminal
print ("  \|/")
print ("   O")



""" Congratulations! You've just created a variety of text art using Python"""
