

"""----------------Task 1: Output few jokes---------------"""
print(" ")
print("*** Task 1:***")
# I am sure you all must have your bag of jokes.
# Let us share them through a Python program.
# Go ahead and display a few jokes, using the print statement.
# The first one is done for you.  
# Uncomment the next 3 lines to see a joke we have put together:
print("What did the spider do on the computer?")
print() # gives a blank line
print ("Made a website!")

# Similarly can you come up some more jokes
print("Knock Knock")
print("Who's there")
print("Orange")
print("Orange Who?")
print("Orange you gonna take me out on a walk?")


"""---------Task-2: Printing Strings in Python------------"""
print(" ")
print("*** Task 2:***")

# Double-quotes (“) and single-quotes (‘) can be used to define a string in Python
# The rule is use the same type of quotes when defining the string.
# Let us use single and double quotes with print.
# Output  "This is a good string" using single quotes 
# Now display  'You are a good programmer' using double-quotes
print('This is a good string')
print("You are a good programmer")


'''-----------Task-3: Combine Multiple Strings ----------'''
print(" ")
print("*** Task 3:***")
# Can you join two strings? 
# We can combine multiple strings using ‘+’
# Uncomment the below print statement and run the code
print("This is " + "a good string")
# Do you see what is displayed? 
# + is used to join 2 string also called as concatenation

''' ------------Task-4: Print Your Name -----------'''
print(" ")
print("*** Task 4:***")
# Can you get Python to print your name on the output terminal window?
# Hint: Use the ‘+’ operator.
print("Hi" +  " My name is Niyati")


'''-----------Task-5 Running into errors ---------------'''
print(" ")
print("*** Task 5:***")
# Below are two print statements with errors.
# Fix the errors, uncomment them  
print("How do you make a hot dog stand?")
print("You take away its chair!")

# Execute the statements to see if you have debugged them

"""Excellent!! You definitely have a keen eye to catch errors."""
