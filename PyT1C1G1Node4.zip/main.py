# How do you introduce yourself when you meet someone? [Wait for the student to respond]
# Are you ready to use the print statement to create a write up about yourself.

''' Task 1: About Me'''
print()
print ("**** Task 1: *****")
# Write a program using the print statements to tell the computer about yourself.
# You can provide information like:
#  - Grade you are studying
#  - Your Favourite subjects
#  - Hobbies you enjoy
#  - Why you like coding
#  - So let's get started!!
print("Hi My name is Niyati, I'm in 9th Grade, I play the violin and I enjoy swimming. My favorite books are the Harry Potter series, Macbeth, and Red Hope")



'''Wow! You definitely have become a pro with the print statements. Way to go.'''