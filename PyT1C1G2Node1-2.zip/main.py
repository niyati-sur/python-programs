
'''***********Task 1: What is a Variable *****************'''
print(" ")
print("*** Task 1:***")
# Variables are data that changes
# It is also a placeholder or a container that hold the data 
# Let’s store a name in a variable.  
# To do that, we will use the assignment operator "=". 
# Uncomment the statements below & run:
#NAME = "Sam"
# Name is the container and the value we stored is “Sam” 
# To display the value stored in the variable, uncomment the next line
#print("Hello " + NAME)
# The print statement outputs the text within quotes, and the value stored in the variable, here it is Sam 
# Don't miss the space within the quote to make it readable. 
# Recollect the Goat Faced with spaces from our previous exercise?

'''***********Task 2: Assignment *****************'''
print(" ")
print("*** Task 2:***")
# You used the assignment operator (=) to store the value "Sam" in the variable NAME  
# NAME       =    "Sam"
# (Left Side)   (Right Side)
# The value on the Right Side is assigned to the variable on the Left Side. 
# Can you assign your favorite colour to a variable called MyFavColour?
# Remember to put your favorite color within quotes

# Now Display it on the console
# Hint: Use the print command  

"""Wow! That's a lovely colour choice.""" 
# Uncomment the next two lines to assign the number 10 to a variable and display it
#NUM=10
#print( NUM)
# Do you see the number displayed? 
# What is the difference between storing a number value and text value to a variable? 
# Text value should be within quotes and quotes are not required for a number. 


'''***********Task 3: Correct Usage *****************'''
print(" ")
print("*** Task 3:***")
# In Python “ = “  is not the same as math equality 
# So a = 4 and 4 = a are not the same
# Lets try
# Uncomment the next two line and Run
#5 = C
#print (C)
# To fix the syntax error, switch the places in the assignment statement
# Change 5 = C to C=5 and now execute the code
# Told you it is not Math! They are different in programming.

'''***********Task 4: Naming Variables *****************'''
print(" ")
print("*** Task 4:***")
# In Algebra we use A, B, C, X, Y and so on as variable names. 
# In Python, it is recommended to give meaningful names to variables.
    # Variable names should follow the below rules:
    # Can contain both letters and numbers 
    # It cannot start with numbers
    # Cannot include keywords like (for, if, and, or…)  
    # Only special characters allowed is an _ (underscore). 
# If you do not follow the rules, you will get a syntax error
# Given below are invalid variable names. Correct them, uncomment and Run to test them 
#007bond = 'big car' 
# Hint:  invalid syntax (starts with a number)
#more@ = 1000000 
# Hint: invalid syntax (Has a special character)
#class = 'noise makers’' 
# Hint: invalid syntax (class is a keyword)

# Can we print a variable without defining, what would happen? Uncomment the next line
#print(trouble)
# What happened? Did you get an error?  [Wait for student answer]
# It is because you have not defined the variable trouble.
# Now define the variable trouble and then print

'''***********Task 5: Using Variables ***'''
print(" ")
print("*** Task 5:***")
# Let’s use more than one variable
# Create a variable called todays_date 
# Assign a value that will represent today’s date to that variable.
# Similarly make two separate variable to store today’s month and year
# Using print statements display today's date, month and year







"""Great! You have created and stored a lot of variables in Python."""