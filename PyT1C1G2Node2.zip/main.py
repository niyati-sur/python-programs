
'''********Task 1: Input*****'''
print(" ")
print("*** Task 1:***")
# Uncomment the next line and take a look at it
NAME = input()
# The input keyword, takes the name from the user and keeps the stores the value in the variable called NAME
# On the output window you will have the cursor blinking waiting for you to enter the input. 
# Now run the statement and enter your name on the output window.
# To display your name, uncomment the next line
print("Hello " + NAME) 
# Hit Run to see how Python can greet you
"""Hurray!!! We did it!! """

'''Task 2: Input Your Name'''
print(" ")
print("*** Task 2:***")
# We just learnt to accept the Name form the user
# Can you accept the surname of the user and greet the user with his/her full name.
# Hint: You will need two input and one print statements 
Surname = input()
print("Hello" + " " + NAME + " " +  Surname)




'''Task 3: Using Input'''
print(" ")
print("*** Task 3:***")
# Now try to change values inside a variable. 
# Uncomment the next 4 lines
NAME = input() 
print(NAME)
NAME = "Batman"
print(NAME)

# What happens when you run the above code?
# Why did you get the name you entered first and Batman later? 
# As Python executes the program line wise. 
# A computer program takes in input, processes it and gives some output. Python does it line wise as it uses an interpreter. 

'''Task 4: Your Data'''
print(" ")
print("*** Task 4:***")
# Uncomment the next statement and check the prompt on the output terminal
Name= input("Enter Your Name")
print(Name)
# What do you see on the terminal? Is it helpful? 
# When we have multiple input statements. We could use a prompt to direct the user what to enter. 
# Now get Python to accept and display all about you
# Write input statements to accept your age, grade and hobbies
# Use appropriate prompts, else you may get confused while entering








'''Task 5: To/Two Display'''
print(" ")
print("*** Task 5:***")
# Write a program that reads one line of input, and prints the same twice.
# For example, if the input is Echo the output should be displayed on the terminal twice like:
# Echo
# Echo
Color = input("enter favorite color")
print(Color)
print(Color)




"""Excellent! You have really gotten the hang of the input statement."""