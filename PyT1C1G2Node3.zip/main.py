'''*****Task 1: Your Lucky Number*****'''
print(" ")
print("*** Task 1:***")
# Let's have some fun. 
# Uncomment the next 4 statements given below one line at a time and check the output
myLuckyNumber=input("Enter your lucky number:")
print(myLuckyNumber)
myLuckyNumber = 5 + 2
print(myLuckyNumber)
# Try computing the value of myLuckyNumber on a paper.
# Did you get your answer? Does it tally with what is displayed on the output window.
# So you have successfully tried to simulate the memory storage of a computer


'''*****Task 2: Your Math*****'''
print(" ")
print("*** Task 2:***")
# Below are a number of arithmetic operations, each assigned to a variable.
# Uncomment each line and display the result on the terminal
mirthful_addition = 12 + 9
amazing_subtraction = 95 - 3
trippy_multiplication = 32 * 989
print(mirthful_addition)
print(amazing_subtraction)
print(trippy_multiplication)


# Did you check the results? Are they correct?
'''*****Task 3: Your Multiplication*****'''
print(" ")
print("*** Task 3:***")
# Multiply two numbers and assign the result to a variable called product. 
# Remember to display the result. 
# Hint: Use the print statement
product = 79 * 8787
print(product)
# Check if the output result is accurate
'''*****Task 4: Your Subtraction*****'''
print(" ")
print("*** Task 4:***")
# Ready for another challenge.
# What is the difference when 13 is subtracted by 11? Save the results in a variable called Minus
Minus = 13-11
print(Minus)

"""Excellent!! You have come a long way. From a single line of code, you are now writing blocks of code."""