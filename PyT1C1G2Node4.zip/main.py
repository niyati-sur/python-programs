# Are you up for some math by building a simple addition calculator.
'''*****Task 1: Additive Calculator*****'''
print(" ")
print("*** Task 1:***")
# Can your program take two numbers from the user and print the sum of the two numbers?
# Uncomment the next 4 lines of code and execute it:
NUM1 = input("number")
NUM2 = input("number")
SUM = NUM1 + NUM2
print(SUM)
# Enter the values 2 and 4 to NUM1 and NUM2 respectively.
# What output do you get? What happened to our calculator? Has it gone insane?
# Why didn't you get the value 6. This is because input() is a function which always returns a text (or a string).
# Recollect our previous example where we used print ("Hello " + NAME + " " + surname). On entering Cuemath for the name and Teacher for surname the output we got was: “ Hello Cuemath Teacher”.
# In similar lines, when you enter the values 2 and 4, Python treats it as a text and hence gives you the output of 2+4 as 24 and not 6. It concatenates the values or in other words  puts it next to each other as it treats the values as strings.
'''*****Task 2: Additive Calculator Fix*****'''
print(" ")
print("*** Task 2:***")
# A variable can have different types of values such as integer, string, etc.
# To be able to do math, we will need to convert the type of value inside the variables from a string to an integer.
# We can do this using the int() function, which converts the string to an integer.
# Uncomment the statements below and see if you get the result:
NUM1 = int(input("num"))
NUM2 = int(input("num"))
# Now the numbers are integers so we can do math on it.
SUM = NUM1 + NUM2
print(SUM)
""" Wow! Our additive calculator is fixed and it works fine now. """
# Test it with some random numbers.
'''*****Task 3: Your Multiplication*****'''
print(" ")
print("*** Task 3:***")
# Accept two numbers from the user.
# Multiply the numbers and assign the result to a variable called product.
# Remember to display the result.
# Hint: Use the print statement]
Num1 = int(input("number please"))
Num2 = int(input("number please"))
Product = Num1 * Num2
print(Product)
# Check if the output is accurate
'''*****Task 4: Arithmatic Calculator*****'''
print(" ")
print("*** Task 4:***")
# Extend the additive calculator to a basic Math calculator
# Write a program that does the following:
# 1. Accept two integers from the user
# 2. Display separately on three lines:
# 3. The sum of the two numbers.
# 4. The difference of the two numbers (first - second).
# 5. The third line contains the product of the two numbers.
num1 = int(input("number:"))
num2 = int(input("another number:"))
SUM = num1 + num2
difference = num1 - num2
product = num1 * num2
print(SUM)
print(difference)
print(product)
'''Kudos!! You have successfully created a simple calculator application using Python.'''
