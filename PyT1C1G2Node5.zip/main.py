# Can you write a program to swap values of two variables
# So what is swapping? 
# Swapping means interchanging the values in those variables. 
# Let us look at an example: 
# Initial values in a and b is : a = 5 and b=7
# We want the values to be interchanged that is a=7 and b=5
# Any idea how to achieve this?
# Is it as easy as you swap books with your friends when the teacher asks for your homework?  
# We need to write specific instructions to make the computer understand.
# To do this, we will use a temporary variable. 
# Recollect the program we have written in our previous task, wherein we accept the name and surname and then swap the values

print(" ")
print("*** Task 1:***")
# Now let us swap the values.
# Uncomment the statements below and run to see how it executes:
NAME = input()  
Surname = input()
print("Hello " + NAME + " " + Surname)

# Now to swap let us make use of another variable called temp
temp = NAME
NAME = Surname
Surname = temp
print("Hello " + NAME + " " + Surname)

# Did it work? This problem is similar to the real life example: 
# We have two mugs with Coffee and Tea written on it. Your mom pours tea into the mug with coffee written on it and fills the mug with tea written on it with coffee. You have the task to swap. How would you do it? Would you mix the two and call it your special ‘TCafe’ shake? (To add some fun elements). But if your mom insists on switching it then? 
# You would need an empty mug which is our temp variable. 
# Hope you understood the use of the Temp variable.
# Can you write the program where the initial state for variables a and b is given and you need to achieve the final state. Let us take these values:

# Initial state: a = 5 and b=7
# Final state:  a=7 and b=5
a = 5
b = 7
print(a, b)
tem = a
a = b
b = tem
print(a, b)


'''Awesome! This is a concept used in many complex programs such as Sorting. We will be learning this very soon.'''