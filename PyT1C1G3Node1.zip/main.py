# In the previous class you used the +, -, * and / operators on numbers .
# Today let us solve some challenging problems. 
# To do this, you need to learn some more operators


'''*****Task 1: Fastest Finger First******'''
print(" ")
print("*** Task 1:***")
# Let us try a quick test to see who is faster - you or the computer?
# Below are a set of problems. 
# 3+4
# 7-5
# 4*3
# 5/3
# First try it on a paper. How long did you take?
#Now uncomment the statements below and click on Run
p=3+4
q=7-5
r=4*3
s=5/3
print(p)
print(q)
print(r)
print(s)
# How long did the computer take to give you the answer? 
# Well who was faster? 
# You see a computer is fast in computing and that is why its is used in all places.
# Uncomment the below statements and click Run
t=5//3
v=7%4
w=2**3
print(t)
print(v)
print(w)
# What did you get? Do you know why? 
# The // operator divides the 5  by 3 and only gives the integer value, not the remainder
# The % (modulus) operator gives the remainder when 7 is divided by 4.
# The ** is used like the exponent operator. So it is read as 2 raised to the power 3

'''*****Task 2: Magical Piggy Bank******'''
print(" ")
print("*** Task 2:***")
# Imagine you get up one morning and discover that  your piggy bank has turned magical. 
# Overnight it has been adding 2 gold coins.
# Now put on your calculating hat and write a python program to get the below answers:
# How many coins will you have if this goes on for a year?  
# Later you realise if you don't check the piggy bank by the end of the week it will take away 1 coin. 
# How much will you be left with ? 
# Had it come true you would have to share half of the coins with me? Now how much will you be left with?
yearlycoin = 2*365
print(yearlycoin)
weeklylost = (int(52))
leftwith = yearlycoin - weeklylost
print(leftwith)
lw2 = leftwith/2
print(lw2) 
'''Great! You are mastering the art of using arithmetic operators  in Python. Way to go!'''