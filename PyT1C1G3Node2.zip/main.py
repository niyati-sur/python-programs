# What if you have an arithmetic problem  with multiple operators and some in brackets?
# Do you know how to solve that? 
# Have you heard of BODMAS?.

'''*****Task 1: BODMAS - Setting the order******'''
print(" ")
print("*** Task 1:***")
# Does BODMAS work in Python programs?
# Why don't you try out?
# Uncomment the following statements and click on Run
p=6 + 10 / 2
q=(6 + 10) / 2
r=2 + 3 * 5
s=(2 + 3) * 5
t=6 +(8 / 4) - 2 * 3
v=(6 + (8 / 4) - 2) * 3
print(p) 
print(q) 
print(r)
print(s) 
print(t) 
print(v) 

'''*****Task 2: Display the Report Card******'''
print(" ")
print("*** Task 2:***")
# Once exams get over we all wait for our report cards.
# You too can create one in Python.
# To start you need to follow the below steps:
# Get the marks for the following subjects from the user : English, Science, Math, Computer Science and History
# Find the total marks and calculate the percentage scored
# Display both the total marks and the average achieved 
# [Hint: Total marks scored divided by the number of subjects gives you the average]
English = int(input("english grade"))
Science = int(input("science grade"))
Math = int(input("math grade"))
ComputerScience = int(input("computer science grade"))
History = int(input("history grade"))
Total = History + ComputerScience + Math + Science + English
Average = Total/5
print(Total)
print(Average)


'''******Task 3:  Grocery Checkout : Lets get calculating******'''
print(" ")
print("*** Task 3:***")
# Ready for a role play.
# You work at the "Freshmart Grocery Shop" as an accountant
# Your manager has given you the following rate card:
# 1 kg of cauliflower - Rs. 30
# 1 kg of potato - Rs. 15
# 1 kg of Onion - Rs. 20
# 1 kg of Beans - Rs 25
# This week happens to be the discount week for customers. 
# You need to give the customer a discount of 10% on the total purchase.
# You have a customer who has bought:
# 2 kg of potato
# 1 kg of onion
# 1 kg of beans 
# 2 kg of cauliflower
# Write a Python program to calculate the amount the customer needs to pay.
Potato = 2*15
onion = 20
beans = 25
cauliflower = 2 * 25
Total = Potato + onion + beans + cauliflower
Discounted_purchase = Total * (10/100)
Total_purchase = Total - Discounted_purchase
print("Total purchase without discount:")
print(Total)

print("discount:", Discounted_purchase)
print("total purchase today:", Total_purchase)
'''Excellent! You have really gotten the hang of working with the arithmetic operators and setting the operator precedence.'''