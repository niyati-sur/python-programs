# Do you know what is the normal temperature for human beings?
# What happens when you get fever?[Wait for the answer]
# Do you know the instrument used to check the temperature of your body? 
# Do you know what is the unit to measuring temperature?
# You will write a program that converts the temperature from Fahrenheit to Celsius. Are you ready?  

'''******Task 1: Fahrenheit to Celsius*****'''
print(" ")
print("*** Task 1:***")
# When you have fever have you heard the doctor say, your temperature is 100 degrees
# Here the doctor is referring to the temperature measured in Farenheit. 
# But we can also measure temperature in celsius.
# To convert the temperature from fahrenheit(°F) to celsius(°C), the formula used is:
# Temperature(°C) = (Temperature in°F) - 32) × 5/9
# Write a python program to convert temperature from fahrenheit to celsius. The program must:
# Take the temperature input from the user and store it in a variable. 
# Remember to mention that the temperature input required should be in fahrenheit.
# Convert the temperature using the formula given above.
# Now display the result [Hint: Use print statement]
Farenheit_temp = float(input("what's the temperature?"))
Celsius_temp = (Farenheit_temp - 32) * 5/9
print("This is the temperature in Celsius!", Celsius_temp)

'''******Task 2: Celsius to Fahrenheit*****'''
print(" ")
print("*** Task 2:***")
# Ready for a small challenge
# Write a program to convert temperature in Celsius to Fahrenheit
# Here is a hint:. Use the following formula.
# Temperature in°F=(Temperature(°C)*9/5)+32
celsius_tem = float(input("What's the temperature"))
faren_temp = (celsius_tem*9/5) + 32
print("This is the temperature in Farenheit!", faren_temp)


'''Excellent! I am so proud of you. Ready for another challenge?'''