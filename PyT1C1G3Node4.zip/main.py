# Do you know in a computer program a variable can hold different values? 
# In Python a variable can hold different values at different times. 
# Let us take a look
'''******Task 1:Task 1: Variable Challenge*****'''
print(" ")
print("*** Task 1:***")
# Do a mental calculation and tell me what the value of the variables first, second and third:
first = 2
second = 3
third = first * second
second = third - first
first = first + second + third
third = second * first
# Uncomment the statements and click on Run
#first = 2
#second = 3
#third = first * second
#second = third - first
#first = first + second + third
#third = second * first
print("First:", first)
print("Second:", second)
print("Third:",third)



'''******Task 2: The ‘x’ challenge*****'''
# What do you think is the value of x after these commands execute? 
# Can you do a mental calculation and tell me
x = 10          
x = x + x
x = x - 5
x = (x*5)/5 + 10
# Uncomment the statements and click on Run
#x = 10          
#x = x + x
#x = x - 5
#x = (x*5)/5 + 10
print("The value of x:",x)


'''Excellent! You were really good with this challenge. Ready for the next level?'''