# Have you ever tried to measure a shadow? 
# Did you know you can measure larger objects like a cliff or a highrise building by measuring its shadow?

'''*****Task 1: Cliff Measure*****'''
print(" ")
print("*** Task 1:***")
# A rock climber wants to know the height of a cliff. 
# You need to write a program to help him calculate. 
# He shares the below information:
# The climber measures the shadow of her friend, who is 5 feet tall and standing beside the cliff 
# He then measures the shadow of the cliff.
# If the friend's shadow is 4 feet  long and the cliff's shadow is 60 feet long, how tall is the cliff?
# Hint: Cliff_height=friend_height * cliff_shadow / friend_shadow
cliff_shadow = 60
friend_shadow = 4
Friend_height = 5
Cliff_height = Friend_height * cliff_shadow/friend_shadow
print("Cliff Height:", Cliff_height)


'''*****Task 2: Fast and Furious*****'''
print(" ")
print("*** Task 2:***")
# Nathan and Ray decided to have a cycling competition on a Sunday. 
# They pulled out  their BTWin cycle and cycled to their favourite picnic spot l20kms from home. 
# Each of them decided to take a separate route to see who reaches faster. 
# Both started at 10:00am. 
# Nathan reached the picnic spot at 11:00am whereas Ray reached at 11:30am. 
# On his way Ray saw a beautiful bird and spent 15 minutes taking its photo.
# Write a Python program that calculates the speed at which each of them cycled and whose route was better.
# [Hint: Speed = Distance travelled/time taken]
Nathan_speed = 120/60
Ray_speed = 120/75
print("nathan's speed in km/min", Nathan_speed)
print("ray's speed in km/min", Ray_speed)


'''*****Task 3: Challenge Galore*****'''
print(" ")
print("*** Task 3:***")
# After the cycling competition Nathan and Ray had on Sunday (as described in the previous task), they decided to take their challenge to the next level.
# They decided to cycle uphill and downhill on a hillock, close to home. 
# But this time they both went together. 
# Here are the details of the distance travelled:
# uphillDistance travelled: 10 km
# downhillDistance travelled: 9 km
# Time taken to go up hill: 66 minutes
# Time taken to come down hill: 46 minutes
# Write a program to calculate the total distance cycled and the average speed taken.
# [Hint: You need to find the total distance, the total time and then calculate the average speed as total distance/total time]
Total_distance = 19
Total_time = 66 + 46
average_speed = Total_distance/Total_time
print("The average speed of Nathan and Ray km/m:", average_speed)






'''Brilliant! You have mastered the techniques of using arithmetic operators in coding. In the next lesson, we shall see how these operators can be used with different data types'''
