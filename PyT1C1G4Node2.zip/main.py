# What if you have a variable of int data type but now want it to be used with values with decimals?
# Can you convert an integer data type  to float data type? 
# Do you know of functions that can help in conversion?
# Let us take a look
"""-----------Task 1: Expression Galore ---------------"""
print(" ")
print("*** Task 1: ***")
# Uncomment the statements and click Run:
a = input("Enter an integer value ")
b = input("Enter a float  value")
c = input("Enter another integer value ")
a = float(a)
b = float(b)
c = float(c)
expr =  (a / b) * c
print ("result is: ", expr)
print(a, b, c)
# Did you get an error? Do you know why? 
# When you divide a number the result can be a decimal number.
# You got an error because when you use both integer and float data types, the computer gets confused.
# So you need to convert the variables to float data type. Do you know why we convert it to float data type? 
# The mathematical calculation can give you a result with decimals. So we will have to convert it to float data type. 
# To convert a variable to float data type, we use the float() function
#For example:
d = input("Enter an integer value ")
d=float(d)
print(d)
# Go back to your code above and convert the int variable to float.
# Hint: You can do the following after accpeting the value from the user:
  #a = float(a)
  #b = float(b)
  #c = float(c)



"""-------Task 2: Visit to the Stationery Shop -----------"""
print(" ")
print("*** Task 2: ***")
# Ready to write a program using different data types.
# Let's start by visiting the stationery shop.
# Ryan has been asked to take care of the accounts at the new stationery shop. 
# The shop sells the following items:
# A Pack of Pencils (20 in number) - Rs.75
# A Pack of BallPoint Pens(5 in number)- Rs.30
# Long Size Notebook - Rs. 127.50
# Regular Size Notebook - Rs. 41.40
# Write a Python program for Ryan, to calculate the total amount,and generate the bill for the customer.
pencil = input("how many packs of pencils?")
pencil = int(pencil)
total_pencil = pencil * 75
pens = input("how many packs of ballpoint pens?")
pens = int(pens)
total_pens = pens * 30
ls_notebook = input("how many large notebooks?")
ls_notebook = int(ls_notebook)
lsn_total = ls_notebook * float(127.50)
rs_notebook = input("how many regular notebooks?")
rs_notebook = int(rs_notebook)
rns_total = rs_notebook * float(41.40)
Total = total_pencil + total_pens + lsn_total + rns_total
print("here's your total", Total)

"""-----------Task 3: Speed Conversion ------"""
print(" ")
print("*** Task 3: ***")
# Write a program to convert the speed from km/hr to m/s
# [Hint:To convert km/hr into m/sec, multiply the number by 5 and then divide it by 18.]
km_per_hr = float(input("how many km/hr?"))
m_s = float(km_per_hr * 5/18)
print("here is how fast you were going in meters per second", m_s)


"""-----------Task 4: Area and Perimeter of Circle ------"""
print(" ")
print("*** Task 4: ***")
#Write a program to accept the radius of a circle, and calculate its area and perimeter. 
#[Hint:Area = 3.14 * (radius) to power of 2    and  Perimeter = 2*3.14*radius]
radius = float(input("what is the radius of your circle"))
area = 3.14 * (radius) ** 2
perimeter = 2 * 3.14 * radius
print(area, perimeter)




'''Awesome! You are becoming a pro in Python programming.You are mastering the use of data types in solving arithmetic problems'''