# If you had to evaluate multiple conditions, how would you do it? 
# Would the if statement handle multiple conditions?
# First let us look at single conditions again and then move to multiple conditions.

"""------Task 1:  Positive or Not --------"""
print(" ")
print("*** Task 1: ***")
# Write a program to take a number as an input from the user.
# Check if the number is positive or negative






"""-----Task 2:  What is your score? ---------"""
print(" ")
print("*** Task 2: ***")
# Write a program to get the marks for Mathematics from the user. 
# If the marks is less than 50, print a message saying “you need to improve”.
# If the mark is more than 50, print “ You are doing good. Keep it up!”






"""------Task 3:  Is it an Equilateral Triangle --------"""
print(" ")
print("*** Task 3: ***")
# Do you know what an equilateral triangle is?
# If all the three sides of a triangle are equal, it's an equilateral triangle. 
# Here is a program to check if a triangle is equilateral.Uncomment the statements and click Run
#a=input("Enter the first side of the triangle:  ")
#b=input("Enter the second side of the triangle: ")
#c=input("Enter the third side of the triangle: ")
#if a != b:
# print( "It is not an equilateral triangle")
#elif a==c:
# print("It is an equilateral triangle")
#else:
# print("It is not an equilateral triangle")
# What do you think the program just did?
# The program checks if the three sides of the triangle are equal (multiple conditions).
# To check multiple conditions  the  “elif” clause has been used
# elif means "else if"
# So how has the if..elif..else been used in the program you just ran (the equilateral triangle program)? 
# The program checked the following conditions: 
# if side 1 is not equal to side 2.
# if it is true, then it means it is not an equilateral triangle
# if it is false, it means side 1 = side 2, so it checks if side 1 = side 3
# if it is true, then it is an equilateral triangle, else it is not
# Note: It is a good practice  to have the last statement as an else.




"""-----Task 4:  Which sides are equal? ---------"""
print(" ")
print("*** Task 4: ***")
# Can you modify the program you ran in Task 1 to check which two sides of the triangle are equal?
# [Hint: Use multiple elif statements]



















'''Kudos!! You handled multiple conditions effortlessly. Way to go!'''