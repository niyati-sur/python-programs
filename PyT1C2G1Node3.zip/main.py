# You used the if elif statement to handle multiple conditions.
# What if you have 10 conditions to evaluate? Will you write 10 if..elif statements? 
# Is it possible to check for more than one condition in a single if statement or elif statement? 
# Let's check it out  



"""-----------Task 1:  All in One ---------------"""
print(" ")
print("*** Task 1: ***")
# Do you know what are isosceles and scalene triangles? 
# Here is a program to check if a triangle is equilateral, scalene or isosceles.
# Uncomment the statements and click Run 
"""a=input("Enter the first side of the triangle:  ")
b=input("Enter the second side of the triangle: ")
c=input("Enter the third side of the triangle: ")
if (a == b) and (a==c):
 print( "Equilateral triangle")
elif a == b and a!= c:
 print("Isosceles triangle.")
elif a == c and a!=b:
 print("Isosceles triangle.")
elif b==c and b!=a:
 print("Isosceles triangle.")
else:
 print("Scalene Triangle")
## Did you get the correct output? What do you think the program just did? 
# and operator is used in an if  statement to check if two or more conditions are true. 
# The above program,checks: 
# if side a is equal to b and side a is also equal to c. If both the conditions are true then it states that it is an equilateral triangle. (if statements)
# if  any two sides are equal to each other, but not the third, then it states it is an isosceles triangle (elif statements)
# if none of the sides are equal it is a scalene triangle (else statement)
# Uncomment the statements are click run
a=int(input("Enter the a number:"))
if a%3==0 or a%4==0:
  print("The number is either divisible by 3 or by 4")
else:
 print("Not divisible")
# What is the output you got? What do you think the program is doing?
# or operator checks if any one of  the conditions in an if statement is true. [Must Say]
# The program that you just executed, checks if the number entered by the user is either divisible by 3 or by 4.  
# The program returns true  
# If the number is divisible by 3 but not by 4
# If the number is divisible by 4 but not by 3
# if the number is divisible by 3 and by 4"""


"""---------Task 2:   Its raining Discount -------------"""
print(" ")
print("*** Task 2: ***")
# Your store is giving a discount on the total purchase amount based on customer membership. 
# Write a program that calculates the discounted amount based on the below mentioned conditions:
# If membership is silver, 5% discount
# If membership is silver+ or gold, discount is 10%
# If membership is gold+ or diamond, discount is 15%
# if membership is platinum membership discount is 20%
"""money = float(input("How many dollars did you spend?"))
membership = input("What is your membership?")
if membership== "silver" :
  discount = money * float(.05)
  total = money-discount
  print("Here is your total!", total)
elif membership == "silver+" or membership == "gold" :
  discount2 = money * 0.1
  total2 =  money-discount2
  print("Here is your total!", total2)
elif membership == "gold+" or membership == "diamond" :
  dis = money * 0.15
  totall = money - dis
  print("Here is your total!", totall)
elif membership == "platinum" :
  discount = money * 0.20
  total = money - discount
  print("Here is your total!", total)
else :
  print("here is your total", money)"""



"""---------Task 3:   Theme Rides -------------"""
print(" ")
print("*** Task 3: ***")
# You are managing the ticket counter at Imaginika Theme Park. Based on the age of the entrant, you issue tickets for the rides"
# Age between 5 and 7 :Toon Tango, Net Walk
# Age between 8 and 12: Wonder Splash, Termite Coaster Train
# Age greater 13: Hang Glider, Wave Rider
# If the age criteria does not match they can go for the nature walks
# Write a program that grants access to the rides based on the age conditions.
age = int(input("How old are you?"))
if age >= 5 and age<=7 :
  print("You can go on these rides: Toon Tango and Net Walk")
elif age >= 8 and age <= 12 :
  print("You can go on these rides: Wonder Splash, Termite Coaster Train")
elif age >= 13 :
  print("You can go on these rides: Hang Glider and Wave Rider")
else :
  print("You can only go on the nature walks, sorry!")






'''You are really becoming an excellent programmer. Way to go!'''





