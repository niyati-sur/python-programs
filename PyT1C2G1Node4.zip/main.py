# Do you know what the Pythagoras Theorem is? 
# The Pythagoras theorem states that “In a right-angled triangle,  the square of the hypotenuse side is equal to the sum of squares of the other two sides“. 
# The sides of this triangle have been named as Perpendicular, Base and Hypotenuse.
# The hypotenuse is the longest side, as it is opposite to the angle 90°.

"""-------Task 1:  What's missing in the right angled triangle? ------"""
print(" ")
print("*** Task 1: ***")

# Write a program to calculate the hypotenuse or one of the sides of the right angled triangle.
question = input("Do you have the measure of the hypotenuse?")
if question == "yes" :
  print("Great! What is the measure?")
  Hypotenuse = float(input("Measure of hypotenuse"))
  side = float(input("1 side length"))
  if Hypotenuse <= side :
    print("Sorry these measurements won't work!")
  else :
    hypotenuse2 = Hypotenuse ** 2
    side2 = side ** 2
    other_side2 = hypotenuse2 - side2
    print("This is your last side squared", other_side2) 
    other_side = other_side2 ** (1/2)
    print("This is your last side!", other_side)

elif question == "no" :
  print("Ok, What is the measure of the two sides then?")
  side1 = float(input("Measure of side 1:"))
  side2 = float(input("Measure of side 2 the bigger side"))
  side12 = side1 ** 2
  side22 = side2 ** 2
  hypotenuse2 = side22 + side12
  print("This is your hypotenuse squared", hypotenuse2)
  hypotenuse = hypotenuse2 ** (1/2)
  print("This is your hypotenuse!", hypotenuse)



else :
  print("Sorry, can't help you find out two of the sides first, thanks!")



''' Awesome!! You have successfully created a Pythagorean Theorem calculator. Congratulations!!'''
