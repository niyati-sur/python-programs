# In the previous class you used the if-elif statements for taking decisions.
# Do you remember your IF statements? 
# Let's take a quiz and check it out.
# Click Run to take a quick quiz

'''-----Task 1: Quiz------'''
'''print("****Task 1: ****")
print("*** Quiz ****")
choice=input("Python makes decisions using if else elif statements.:\n 1. True \n 2. False \n Enter the number choice : ")
if choice=="1":
  print("Correct")
elif choice=="2":
  print("Incorrect")
else:
  print("You have not selected the correct number choice. The answer is True.")   
print()
choice=input("_____ operator is used to check if both the conditions being evaluated have to be true:\n 1. or \n 2. and \n Enter the number choice : ")
if choice=="1":
  print("Incorrect")
elif choice=="2":
  print("Correct")
else:
  print("You have not selected the correct number choice. The answer is - and")
print()
choice=input("In an if statement with multiple elif, the last statement should be else:\n 1. True \n 2. False \n Enter the number choice : ")
if choice=="1":
  print("Incorrect")
elif choice=="2":
  print("Correct")
else:
  print("You have not selected the correct number choice. The answer is True.")
print() 
choice=input("You can have more than one \'and\' operator in an if statement.:\n 1. True \n 2. False \n Enter the number choice : ")
if choice=="1":
  print("Correct")
elif choice=="2":
  print("Incorrect")
#else:
  print("You have not selected the correct number choice. The answer is True.")

# How did the quiz go? How many questions did you get correct?
# Do you know the quiz has been created using the if statements?Why don't you take a look at the program?'''


'''-----Task 2: Grade Detector ------'''
'''print("****Task 2: ****")
print()
# Given below is a program that takes a score as the input and then returns a grade.
# The program returns the following Grades:
#  90 or higher gets an “A”
#  80 - 89 gets a “B”
#  70 - 79 gets a “C”
#  60 - 69 gets a “D”
# Anything below a 60 receives an “F”
# The missing pieces in the program are the incomplete if statements.
# You need to write the appropriate if statements, to generate the correct grades.
# Uncomment the statements below and write the appropriate if and elif statement

score =int (input ("Enter your score "))
if score >= 90 :
 print ("A")
elif score >= 80 :
 print ("B")
elif score >= 70 :
 print ("C")
elif score >= 60 :
 print ("D")
else:
 print ("F")'''

'''-----Task 3: FizzBuzz Game ------'''
'''print("****Task 3: ****")
print()
# Write a program to accept an integer from the user. 
# If the number is a multiple of 3, print "Fizz" 
# If the number is a multiple of 5, print "Buzz"
# If the number is a multiple of 3 and 5, print "FizzBuzz"
number = float(input("Enter a number and we'll tell you if it's a multiple of 3 or 5!"))  
if number %3 == 0 and number %5 == 0:
  print("FizzBuzz!")
elif number %5 == 0 :
  print("Buzz")
elif number %3 == 0 :
  print("Fizz")
else :
  print("Sorry, the number you entered isn't a multiple of 3 nor 5.")'''





'''-----Task 4: Spanish Animal Dictionary ------'''
print("****Task 4: ****")
print()  
# Have you used a dictionary? What is the purpose of a dictionary? 
# How many languages do you know besides english?
# Ready to create a simple dictionary that tell you the Spanish meaning of different animals in English  
# Use the English to Spanish list below to start
#  Cat - el gato
#  Dog - el perro
#  Fish - el pescado
#  Hamster - el hamster
#  Rabbit - el conejo
# The first few statements have been done for you. Uncomment the statements below and complete the program

print("Welcome to the English-Spanish translator for animals!!")
word = int(input("Please select a number\n: 1-Cat  2-Dog  3-Fish  4-Hamster  5-Rabbit\n"))
if word == 1:
 print("In Spanish cat is: el gato")
elif word == 2:
  print("In Spanish, Dog is: el perro")
elif word == 3 :
  print("In spanish fish is: el pescado")
elif word == 4 :
  print("In Spanish, Hamster is: el hamster")
elif word == 5 :
  print("In spanish rabbit is: el conejo")
else :
  print("The number you have chosen is not valid, please try again.")

'''Great! You have taken the first step towards creating interactive programs.''' 