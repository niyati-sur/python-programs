# How do you solve complex calculations or problems?
# You could use a calculator or take help form a learned person
# You would provide the necessary information to arrive at the solution
# What if you could do this on a computer? Lets Try!
'''-----Task 1: ------'''
print("****Task 1: ****")
print()
# Uncomment the statements and click Run
'''name = input("Hi, what is your name? ")
print("It is lovely to meet you ", name)
feeling = int(
    input(
        "How are you feeling today? Excited =1, Happy = 2, Miserable = 3, Nervous= 4 \n"
    ))
if feeling == 1:
    print("Fantastic!! Here is a riddle to keep up the excitement.\n")
    print("What kind of room has no doors or windows?\n ")
    print("Answer: Mushroom")
elif feeling == 2:
    print("I am happy too, Yay!!Here is a riddle to keep up the happiness.\n")
    print("Why are teddy bears never hungry?\n")
    print("Answer: Because they are always stuffed")
elif feeling == 3:
    print(
        "I am sorry to hear that you feel miserable. Here is a riddle to cheer you up.\n?"
    )
    print("What is the longest word in the dictionary?\n")
    print("Answer: Smiles, because there is a mile between each “s”")
elif feeling == 4:
    print(
        "Hmm. I am sure you will get over it. Here is a riddle to boost your confidence.\n?"
    )
    print("You can hear it, but not touch or see it. What is it? \n")
    print("Answer: Your voice")
else:
    print("Select the correct number. Try again")'''
'''-----Task 2: Speed, Distance, Time Calculator------'''
'''print("****Task 2: ****")
print()'''
# Write a program which calculates the speed or distance or time depending on the inputs provided by the user
# Ask the user what they want to calculate and depending on the response, ask for the required inputs,
# For example if the user says the speed needs to be calculated, take the distance and time as the input from the user
# speed=distance/time
# time=speed/distance
# distance=speed*time
user_calc = input("What do you want to calculate, (1/2/3)? \n1.speed\n2.distance\n3.time\n ")
if user_calc == "1" :
  distance = float(input("How much is the distance?(kilometers)"))
  Time = float(input("How much time?(hour)"))
  speed = distance/Time
  print("Here's the speed:\n", speed, "km per hour")
elif user_calc == "2" :
  speed = float(input("How much speed?(kilometers/hour)"))
  Time = float(input("How much time?hour"))
  distance = speed * Time
  print("Distance:\n", distance, "kilometers")
elif user_calc == "3" :
  speed = float(input("Speed?(kilometers/hour)"))
  distance = float(input("Distance?(kilometers)"))
  Time = distance/speed
  print("Here is the time:\n", Time, "hour")
else :
  print("Sorry, the number you entered wasn't valid. Please try again!")





'''-----Task 3: Total Score------'''
print("****Task 3: ****")
print()
# Write a program that takes the Maths theory and Maths lab score.
# Each of the score cannot be more than 50
# Calculate the total score and print the result
mt = float(input("What is your grade in Math theory?\n"))
ml = float(input("What is your grade in Math Lab?\n"))
if mt <= 50 and ml <= 50 :
  mtotal = mt + ml
  print(mtotal)
else :
  print("Sorry, both the scores have to be less than or equal to 50")



'''Brilliant! You are really good with decision making programs. Way to go!!'''
